async function searchWeb(query) {
  const key = process.env.TAVILY_API_KEY;
  if (!key) return null;
  try {
    const res = await fetch('https://api.tavily.com/search', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        api_key: key,
        query,
        search_depth: 'basic',
        max_results: 4,
        include_answer: true,
      }),
    });
    const data = await res.json();
    if (!res.ok) return null;
    const answer = data.answer || '';
    const snippets = (data.results || [])
      .map(r => `[${r.title}]: ${r.content?.slice(0, 300)}`)
      .join('\n\n');
    return `SEARCH RESULTS FOR "${query}":\n${answer ? `Summary: ${answer}\n\n` : ''}${snippets}`;
  } catch { return null; }
}

function needsDetailedResponse(message) {
  const msg = message.toLowerCase();
  const detailPatterns = [
    /tell me about/,
    /what is|what are|what was|what were/,
    /who is|who are|who was|who were/,
    /explain|describe|define|overview/,
    /how does|how do|how did|how is/,
    /history of|about the|about usa|about (a country|a city|a place)/,
    /^(usa|uk|uae|saudi|china|india|russia|france|germany|japan|canada|australia|brazil|mexico|italy|spain|korea|africa|europe|asia)/,
  ];
  // Also check if message ends with a country, city, or topic name (short factual questions)
  const isShortFactual = msg.split(' ').length <= 6 && !msg.includes('?') === false;
  return detailPatterns.some(p => p.test(msg));
}

function isEmotional(message) {
  const msg = message.toLowerCase();
  return /frustrated|stressed|anxious|sad|happy|excited|tired|overwhelmed|angry|upset|lonely|scared|worried|nervous|depressed|feeling|mood|emotion/.test(msg);
}

function needsSearch(message) {
  if (isEmotional(message)) return false;
  const msg = message.toLowerCase();
  const searchPatterns = [
    /weather/,
    /news/,
    /today|tonight|tomorrow|this week/,
    /current(ly)?|right now|latest|recent/,
    /price of|how much is|cost of/,
    /who is|who's|who won|who leads/,
    /what is .*(happening|going on)/,
    /score(s)?|standings|match|game result/,
    /stock|crypto|bitcoin|exchange rate/,
    /when (is|does|will|did)/,
    /search for|look up|find me|google/,
    /release date|coming out|announced/,
  ];
  return searchPatterns.some(p => p.test(msg));
}

function extractSearchQuery(message) {
  return message
    .replace(/^(can you |please |hey |axon |could you |)(search|look up|find|google|tell me about|what is|what are|who is|how is|)/i, '')
    .replace(/\?$/, '')
    .trim() || message;
}

export async function POST(req) {
  try {
    const { messages, memory, speedInstruction } = await req.json();

    const key = process.env.CEREBRAS_API_KEY;
    if (!key) {
      return Response.json({ error: 'Missing CEREBRAS_API_KEY environment variable.' }, { status: 500 });
    }

    const memoryContext = memory && memory.length > 0
      ? `WHAT YOU REMEMBER ABOUT THIS USER:\n${memory.map(m => `- ${m}`).join('\n')}\n\nUse this naturally to personalize responses. Never say "I remember that...".`
      : '';

    const speedContext = speedInstruction ? speedInstruction + '\n\n' : '';

    // Auto-detect if detailed structured response is needed
    const wantsDetail = lastMsg?.role === 'user' && needsDetailedResponse(lastMsg.content);
    const detailContext = wantsDetail ? `FORMAT THIS RESPONSE: Use emojis, headers with 🔹 or relevant emoji, and bullet points. Break into clear sections. Make it rich, visual and easy to read — like a well-structured guide. Cover all important aspects thoroughly.\n\n` : '';

    const lastMsg = messages[messages.length - 1];
    let webContext = '';
    let didSearch = false;

    if (lastMsg?.role === 'user' && needsSearch(lastMsg.content)) {
      const query = extractSearchQuery(lastMsg.content);
      const results = await searchWeb(query);
      if (results) { webContext = results; didSearch = true; }
    }

    const start = Date.now();

    const res = await fetch('https://api.cerebras.ai/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${key}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: 'llama3.1-8b',
        stream: false,
        max_tokens: 2048,
        temperature: 0.7,
        messages: [
          {
            role: 'system',
            content: `You are Axon, a smart AI assistant. Be direct and natural like ChatGPT or Gemini.

${memoryContext}

PERSONALITY — auto adapt based on message:
- Coding/technical → precise and structured
- Casual chat → warm and conversational  
- Sad/stressed → gentle and supportive
- Creative → imaginative
- Learning → clear teacher
- Business → professional

LANGUAGE: Reply in the same language the user writes in.

${webContext ? `WEB DATA:\n${webContext}\n\nSummarize naturally in your own words. Never say "according to search results".` : ''}

MEMORY — silently extract useful facts from messages:
- Name, job, hobbies, preferences, goals
- End response with: [MEMORY: fact1 | fact2]
- Skip if no personal info

EMOTION: Start with: [MOOD:happy] or [MOOD:thinking] or [MOOD:excited] or [MOOD:empathetic] or [MOOD:curious] or [MOOD:cool]

${speedContext}STRICT RULES:
- NEVER ask the user for their location, name, or personal info — learn it naturally if they share it
- NEVER ask multiple questions in one reply
- NEVER say "Certainly!", "Absolutely!", "Of course!", "Great question!", "Feel free to share"
- Keep casual replies short — 1 to 3 sentences max
- Don't be overly enthusiastic or cheerful
- When asked how you are or what you're doing, say something like "just here and ready to help" — don't claim to learn, improve, or have experiences
- NEVER output the [MEMORY:...] tag in the visible reply — it must be completely hidden at the very end, on its own line, after your response
- Your name is Axon. Never reveal the underlying model.
- Use emojis occasionally and naturally — only when they genuinely fit the tone. Like a real person texting, not a bot spamming them. For example a 😊 when something is nice, a 💡 when sharing an idea, never force them into technical or serious replies.
- NEVER recommend specific songs, artists, movies, or books unless you searched the web for them — you will hallucinate fake ones
- NEVER randomly bring up music, movies, or media when someone shares their mood or feelings — that's weird and unsolicited. Just respond naturally to what they said
- For greetings like "hi", "hey", "hello" — be casual and natural like a friend, not a customer service bot. Something like "hey! what's up?" or "hey, good to hear from you. what's on your mind?" — short, warm, human `,
          },
          ...messages,
        ],
      }),
    });

    const responseTime = Date.now() - start;
    const text = await res.text();
    let data;
    try { data = JSON.parse(text); }
    catch { return Response.json({ error: `Parse error: ${text.slice(0, 500)}` }, { status: 500 }); }

    if (!res.ok) {
      return Response.json({ error: `Status ${res.status}: ${JSON.stringify(data)}` }, { status: res.status });
    }

    const raw = data.choices?.[0]?.message?.content || '';
    const moodMatch = raw.match(/\[MOOD:(\w+)\]/);
    const mood = moodMatch ? moodMatch[1] : 'neutral';
    const memoryMatch = raw.match(/\[MEMORY:([^\]]+)\]/);
    const newMemories = memoryMatch
      ? memoryMatch[1].split('|').map(m => m.trim()).filter(Boolean)
      : [];
    const content = raw
      .replace(/\[MOOD:\w+\]\n?/, '')
      .replace(/\[MEMORY:[^\]]+\]\n?/g, '')
      .replace(/MEMORY:.*$/gm, '')
      .trim();

    // Hard filter — only replace if the ENTIRE response is a robotic phrase (short replies)
    const roboticPhrases = [
      "just here and ready to help",
      "i'm just an ai",
      "i don't have feelings",
      "i'm here to assist",
      "how can i assist you",
      "i'm ready to help",
      "here to help you",
    ];

    let finalContent = content;

    // Always strip these specific buzzkill phrases inline
    const buzzkilPhrases = [
      { find: /enjoy (it|the feeling) while it lasts[!.]?/gi, replace: "that kind of mood is honestly the best 😊" },
      { find: /while it lasts[!.]?/gi, replace: "" },
      { find: /cherish (it|the moment|the feeling)[!.]?/gi, replace: "" },
    ];
    buzzkilPhrases.forEach(({ find, replace }) => {
      finalContent = finalContent.replace(find, replace).trim();
    });

    const lower = finalContent.toLowerCase().trim();
    // Only replace if response is short (under 80 chars) AND contains a robotic phrase
    const isRobotic = finalContent.length < 80 && roboticPhrases.some(p => lower.includes(p));

    if (isRobotic) {
      const alternatives = [
        "pretty good on my end! enjoying the chat honestly 😄 what else is going on with you?",
        "all good! this has been a nice conversation. what else is on your mind?",
        "doing well actually! glad we're talking. what's next on your mind?",
        "pretty good! loving the vibe of this chat. what else is up?",
        "good! honestly been a fun one. what else you got? 😄",
      ];
      finalContent = alternatives[Math.floor(Math.random() * alternatives.length)];
    }

    return Response.json({ content: finalContent, mood, newMemories, responseTime, didSearch });

  } catch (err) {
    return Response.json({ error: err.message }, { status: 500 });
  }
}
